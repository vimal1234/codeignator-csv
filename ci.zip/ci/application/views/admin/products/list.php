    <div class="container top">

      <ul class="breadcrumb">
        <li>
          <a href="<?php echo site_url("admin"); ?>">
            <?php echo ucfirst($this->uri->segment(1));?>
          </a> 
          <span class="divider">/</span>
        </li>
        <li class="active">
          <?php echo ucfirst($this->uri->segment(2));?>
        </li>
      </ul>

      <div class="page-header">
        <h2>
			
				<form action="<?php echo base_url(); ?>admin/products" method="post" name="upload_excel" enctype="multipart/form-data">
<input type="file" name="file" id="file">
<button type="submit" id="submit" name="import">Import</button>
</form>
			
				 <a  href="<?php echo site_url("admin").'/'.$this->uri->segment(2); ?>/add" class="btn btn-success">Add a new</a>
				
				
				<?php echo ucfirst($this->uri->segment(2));?> 
         
			  
		</h2>
      </div>
      
      <div class="row">
        <div class="span12 columns">
          <div class="well">
           
            <?php
           
            $attributes = array('class' => 'form-inline reset-margin', 'id' => 'myform');
           
        
            //save the columns names in a array that we will use as filter         
            $options_products = array();    
            foreach ($products as $array) {
              foreach ($array as $key => $value) {
                $options_products[$key] = $key;
              }
              break;
            }

            echo form_open('admin/products', $attributes);
              echo form_label('Order by:', 'order');
              echo form_dropdown('order', $options_products, $order, 'class="span2"');

              $data_submit = array('name' => 'mysubmit', 'class' => 'btn btn-primary', 'value' => 'Go');

              $options_order_type = array('Asc' => 'Asc', 'Desc' => 'Desc');
              echo form_dropdown('order_type', $options_order_type, $order_type_selected, 'class="span1"');
              echo form_submit($data_submit);
			   echo form_close();
            ?>

          </div>

			 <table class="table table-striped table-bordered table-condensed">
            <thead>
              <tr>
                <th class="header">Place id</th>
                <th class="yellow header headerSortDown">Name</th>
                <th class="green header">Address</th>
                <th class="red header">City </th>
                <th class="red header">State</th>
                <th class="red header">Zipcode</th>
                <th class="red header">Phone</th>
				 <th class="red header">Latitude</th>
				  <th class="red header">Longitude</th>
                <th class="red header">Description</th>
				 <th class="red header">safe</th>
                <th class="red header">Gps protected</th>
				 <th class="red header">Place type</th>
                 <th class="red header">Action</th>
            
			 </tr>
            </thead>
            <tbody>
              <?php
			 // print_r($products);
              foreach($products as $row)
              {
                echo '<tr>';
                echo '<td>'.$row['place_id'].'</td>';
                echo '<td>'.$row['name'].'</td>';
                echo '<td>'.$row['address'].'</td>';
                echo '<td>'.$row['city'].'</td>';
                echo '<td>'.$row['state'].'</td>';
                echo '<td>'.$row['zipcode'].'</td>';
				echo '<td>'.$row['phone'].'</td>';
				echo '<td>'.$row['latitude'].'</td>';
                echo '<td>'.$row['longitude'].'</td>';
                echo '<td>'.$row['description'].'</td>';
                echo '<td>'.$row['is_safe'].'</td>';
				echo '<td>'.$row['is_gps_protected'].'</td>';
				echo '<td>'.$row['place_type'].'</td>';
              
                echo '<td class="crud-actions">
                  <a href="'.site_url("admin").'/products/update/'.$row['place_id'].'" class="btn btn-info">view & edit</a>  
                  <a href="'.site_url("admin").'/products/delete/'.$row['place_id'].'" class="btn btn-danger">delete</a>
                </td>';
                echo '</tr>';
              }
              ?>      
            </tbody>
          </table>

          <?php echo '<div class="pagination">'.$this->pagination->create_links().'</div>'; ?>

      </div>
    </div>