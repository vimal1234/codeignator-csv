<?php
class Products_model extends CI_Model {
 
    /**
    * Responsable for auto load the database
    * @return void
    */
    public function __construct()
    {
        $this->load->database();
    }

    /**
    * Get product by his is
    * @param int $product_id 
    * @return array
    */
    public function get_product_by_id($id)
    {
		$this->db->select('*');
		$this->db->from('products');
		$this->db->where('id', $id);
		$query = $this->db->get();
		return $query->result_array(); 
    }

    /**
    * Fetch products data from the database
    * possibility to mix search, filter and order
    * @param int $manufacuture_id 
    * @param string $search_string 
    * @param strong $order
    * @param string $order_type 
    * @param int $limit_start
    * @param int $limit_end
    * @return array
    */
	 public function insertCSV($data)
            {
                $this->db->insert('place_mst', $data);
                return TRUE;
            }

    public function get_products($order=null, $order_type='Asc', $limit_start, $limit_end)
    {
	  
		$this->db->select('place_mst.place_id');
		$this->db->select('place_mst.name');
		$this->db->select('place_mst.address');
		$this->db->select('place_mst.city');
		$this->db->select('place_mst.state');
		$this->db->select('place_mst.zipcode');
		$this->db->select('place_mst.phone');
		$this->db->select('place_mst.latitude');
		$this->db->select('place_mst.longitude');
		$this->db->select('place_mst.description');
		$this->db->select('place_mst.is_safe');
		$this->db->select('place_mst.is_gps_protected');
		$this->db->select('place_mst.place_type');
		$this->db->from('place_mst'); 
		
	
	
		$this->db->group_by('place_mst.place_id');

		if($order){
			$this->db->order_by($order, $order_type);
		}else{
		    $this->db->order_by('place_mst.place_id', $order_type);
		}


		$this->db->limit($limit_start, $limit_end);
		//$this->db->limit('4', '4');


		$query = $this->db->get();
		
		return $query->result_array(); 	
    }

    /**
    * Count the number of rows
    * @param int $manufacture_id
    * @param int $search_string
    * @param int $order
    * @return int
    */
    function count_products($order=null)
    {
		$this->db->select('*');
		$this->db->from('place_mst');
			if($order){
			$this->db->order_by($order, 'Asc');
		}else{
		    $this->db->order_by('place_mst.place_id', 'Asc');
		}
		$query = $this->db->get();
		return $query->num_rows();        
    }

    /**
    * Store the new item into the database
    * @param array $data - associative array with data to store
    * @return boolean 
    */
    function store_product($data)
    {
		$insert = $this->db->insert('products', $data);
	    return $insert;
	}

    /**
    * Update product
    * @param array $data - associative array with data to store
    * @return boolean
    */
    function update_product($id, $data)
    {
		$this->db->where('id', $id);
		$this->db->update('products', $data);
		$report = array();
		$report['error'] = $this->db->_error_number();
		$report['message'] = $this->db->_error_message();
		if($report !== 0){
			return true;
		}else{
			return false;
		}
	}

    /**
    * Delete product
    * @param int $id - product id
    * @return boolean
    */
	function delete_product($id){
		$this->db->where('id', $id);
		$this->db->delete('products'); 
	}
 
}
?>	
